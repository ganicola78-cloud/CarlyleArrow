package com.example.carlylearrow;

import android.app.Activity;
import android.os.Bundle;
import android.os.Vibrator;
import android.content.Context;
import android.graphics.*;
import android.view.*;
import android.view.Window;
import android.view.WindowManager;
import com.google.android.gms.wearable.*;
import java.util.*;

public class MainActivity extends Activity implements DataClient.OnDataChangedListener {
    ArrowView view;
    Vibrator vibrator;
    String lastId = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        vibrator = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
        view = new ArrowView(this);
        setContentView(view);
    }
    @Override protected void onResume(){ super.onResume(); Wearable.getDataClient(this).addListener(this); }
    @Override protected void onPause(){ Wearable.getDataClient(this).removeListener(this); super.onPause(); }

    @Override public void onDataChanged(DataEventBuffer events) {
        for (DataEvent e: events) {
            if (e.getType()!=DataEvent.TYPE_CHANGED) continue;
            DataItem item=e.getDataItem();
            if (!"/carlyle_arrow/nav".equals(item.getUri().getPath())) continue;
            DataMap m=DataMapItem.fromDataItem(item).getDataMap();
            String id=m.getString("id", "");
            String dir=m.getString("direction", "straight");
            String distance=m.getString("distance", "");
            String street=m.getString("street", "");
            String source=m.getString("source", "Maps");
            if (!id.equals(lastId) && vibrator!=null) { vibrator.vibrate(180); lastId=id; }
            runOnUiThread(() -> view.setInstruction(dir,distance,street,source,false));
        }
    }

    public static class ArrowView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        String direction="right", distance="300 m", street="Via Roma", source="DEMO";
        boolean waiting=false;
        int demo=0;
        String[][] demos={{"right","300 m","Via Roma","DEMO"},{"left","150 m","Wall St","DEMO"},{"straight","1,4 km","Continua dritto","DEMO"},{"slight_right","2,8 km","D1 Quai de Clichy","DEMO"},{"uturn","80 m","Inversione","DEMO"}};
        public ArrowView(Context c){ super(c); setBackgroundColor(Color.BLACK); setFocusable(true); setOnClickListener(v->{demo=(demo+1)%demos.length; setInstruction(demos[demo][0],demos[demo][1],demos[demo][2],demos[demo][3],false);}); setOnLongClickListener(v->{setInstruction("straight","","In attesa notifiche Maps/Waze","WAIT",true); return true;}); }
        public void setInstruction(String d,String dist,String st,String src,boolean w){direction=d;distance=dist;street=st;source=src;waiting=w;invalidate();}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); int w=getWidth(), h=getHeight(); float cx=w/2f; p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(22); p.setStrokeCap(Paint.Cap.SQUARE); p.setStrokeJoin(Paint.Join.ROUND);
            c.save(); c.translate(cx, h*0.28f); drawArrow(c, direction); c.restore();
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
            p.setTextSize(waiting?22:46); c.drawText(waiting?"In attesa":distance, cx, h*0.58f, p);
            p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)); p.setTextSize(28);
            drawMultiline(c, street, cx, h*0.71f, w*0.82f, 32);
            p.setTextSize(17); p.setColor(Color.LTGRAY); c.drawText(source, cx, h-18, p);
        }
        void drawArrow(Canvas c,String d){ Path path=new Path();
            if (d.contains("left")) { path.moveTo(55,-40); path.lineTo(-35,-40); path.lineTo(-35,35); path.moveTo(-35,-40); path.lineTo(-5,-72); path.moveTo(-35,-40); path.lineTo(-5,-8); }
            else if (d.contains("uturn")) { path.moveTo(38,60); path.lineTo(38,-25); path.quadTo(38,-75,-15,-75); path.lineTo(-45,-75); path.moveTo(-45,-75); path.lineTo(-15,-105); path.moveTo(-45,-75); path.lineTo(-15,-45); }
            else if (d.contains("slight")) { path.moveTo(-15,75); path.lineTo(-15,-10); path.quadTo(-15,-55,35,-75); path.moveTo(35,-75); path.lineTo(5,-88); path.moveTo(35,-75); path.lineTo(20,-43); }
            else if (d.contains("right")) { path.moveTo(-45,65); path.lineTo(-45,-20); path.quadTo(-45,-55,12,-55); path.lineTo(55,-55); path.moveTo(55,-55); path.lineTo(25,-85); path.moveTo(55,-55); path.lineTo(25,-25); }
            else { path.moveTo(0,70); path.lineTo(0,-75); path.moveTo(0,-75); path.lineTo(-35,-38); path.moveTo(0,-75); path.lineTo(35,-38); }
            c.drawPath(path,p);
        }
        void drawMultiline(Canvas c,String text,float x,float y,float maxW,float lineH){ if(text==null)text=""; String[] words=text.split(" "); String line=""; int count=0; for(String word:words){ String test=line.length()==0?word:line+" "+word; if(p.measureText(test)>maxW && line.length()>0){ c.drawText(line,x,y+count*lineH,p); line=word; count++; } else line=test; if(count>=2) break; } if(count<3)c.drawText(line,x,y+count*lineH,p); }
    }
}
