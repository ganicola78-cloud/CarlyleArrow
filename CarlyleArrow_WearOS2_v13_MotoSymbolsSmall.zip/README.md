Carlyle Arrow Watch v13 - simboli moto più piccoli e separati dai metri.
