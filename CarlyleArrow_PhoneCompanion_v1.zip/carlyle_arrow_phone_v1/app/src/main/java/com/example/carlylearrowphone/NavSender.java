package com.example.carlylearrowphone;
import android.content.*;import com.google.android.gms.wearable.*;
public class NavSender{
 static void send(Context ctx,String direction,String distance,String street,String source){
  PutDataMapRequest req=PutDataMapRequest.create("/carlyle_arrow/nav");
  DataMap m=req.getDataMap(); m.putString("id", source+":"+direction+":"+distance+":"+street+":"+System.currentTimeMillis()/1000); m.putString("direction",direction); m.putString("distance",distance); m.putString("street",street); m.putString("source",source); m.putLong("ts",System.currentTimeMillis());
  PutDataRequest p=req.asPutDataRequest(); p.setUrgent(); Wearable.getDataClient(ctx).putDataItem(p);
 }
}
