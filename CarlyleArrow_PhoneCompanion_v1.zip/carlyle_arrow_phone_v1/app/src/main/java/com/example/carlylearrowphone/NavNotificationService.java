package com.example.carlylearrowphone;
import android.app.Notification;import android.os.Bundle;import android.service.notification.*;import java.util.*;

public class NavNotificationService extends NotificationListenerService{
 private static final Set<String> APPS=new HashSet<>(Arrays.asList("com.google.android.apps.maps","com.waze"));
 @Override public void onNotificationPosted(StatusBarNotification sbn){
  if(!APPS.contains(sbn.getPackageName())) return;
  Notification n=sbn.getNotification(); if(n==null) return; Bundle e=n.extras; if(e==null) return;
  String title=txt(e.getCharSequence(Notification.EXTRA_TITLE));
  String text=txt(e.getCharSequence(Notification.EXTRA_TEXT));
  String big=txt(e.getCharSequence(Notification.EXTRA_BIG_TEXT));
  String all=(title+" "+text+" "+big).trim(); if(all.length()<2) return;
  String distance=extractDistance(all); String direction=extractDirection(all); String street=extractStreet(all,distance);
  NavSender.send(this,direction,distance,street,sbn.getPackageName().contains("waze")?"Waze":"Maps");
 }
 String txt(CharSequence c){return c==null?"":c.toString();}
 String extractDistance(String s){ java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d+[,.]?\\d*\\s?(?:m|km|ft|mi))",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(s); return m.find()?m.group(1).replace('.',','):""; }
 String extractDirection(String s){String l=s.toLowerCase(Locale.ITALIAN); if(l.contains("inversion")||l.contains("u-turn"))return"uturn"; if(l.contains("sinistra")||l.contains("left"))return"left"; if(l.contains("destra")||l.contains("right"))return l.contains("legger")||l.contains("slight")?"slight_right":"right"; if(l.contains("continua")||l.contains("dritto")||l.contains("straight"))return"straight"; return"straight";}
 String extractStreet(String s,String dist){String out=s; if(dist!=null&&dist.length()>0)out=out.replace(dist,""); out=out.replaceAll("(?i)tra|fra|svolta|gira|continua|a destra|a sinistra|leggermente|su|verso|then|turn|right|left|onto", " ").replaceAll("\\s+"," ").trim(); if(out.length()>42)out=out.substring(0,42); return out.length()==0?s:out;}
}
