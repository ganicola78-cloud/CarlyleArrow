package com.example.carlylearrow;

import android.content.Context;
import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.PutDataMapRequest;
import com.google.android.gms.wearable.PutDataRequest;
import com.google.android.gms.wearable.Wearable;
import java.util.List;

public class NavSender {
    public interface Callback { void done(String msg); }

    static void send(Context ctx, String direction, String distance, String street, String source) {
        send(ctx, direction, distance, street, source, null);
    }

    static void send(Context ctx, String direction, String distance, String street, String source, Callback cb) {
        final String d = direction == null ? "straight" : direction;
        final String dist = distance == null ? "" : distance;
        final String st = street == null ? "" : street;
        final String src = source == null ? "" : source;
        final String payload = d + "|" + dist + "|" + st + "|" + src + "|" + System.currentTimeMillis();

        PutDataMapRequest req = PutDataMapRequest.create("/carlyle_arrow/nav");
        DataMap m = req.getDataMap();
        m.putString("id", payload);
        m.putString("direction", d);
        m.putString("distance", dist);
        m.putString("street", st);
        m.putString("source", src);
        m.putLong("ts", System.currentTimeMillis());
        PutDataRequest p = req.asPutDataRequest();
        p.setUrgent();

        Wearable.getDataClient(ctx).putDataItem(p)
            .addOnFailureListener(e -> { if (cb != null) cb.done("Errore DataItem: " + e.getMessage()); });

        Wearable.getNodeClient(ctx).getConnectedNodes()
            .addOnSuccessListener(nodes -> {
                if (nodes.size() == 0) {
                    if (cb != null) cb.done("Nessun nodo Wear OS trovato. Carlyle non visto dal telefono.");
                    return;
                }
                final int[] sent = {0};
                for (Node n : nodes) {
                    Wearable.getMessageClient(ctx).sendMessage(n.getId(), "/carlyle_arrow/navmsg", payload.getBytes())
                        .addOnSuccessListener(i -> { sent[0]++; if (cb != null) cb.done("Test inviato. Nodi: " + nodes.size() + " | Messaggi OK: " + sent[0]); })
                        .addOnFailureListener(e -> { if (cb != null) cb.done("Nodo trovato ma invio fallito: " + e.getMessage()); });
                }
            })
            .addOnFailureListener(e -> { if (cb != null) cb.done("Errore nodi Wear OS: " + e.getMessage()); });
    }
}
