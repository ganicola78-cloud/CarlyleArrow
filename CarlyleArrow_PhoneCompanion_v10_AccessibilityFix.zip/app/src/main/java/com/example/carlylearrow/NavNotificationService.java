package com.example.carlylearrow;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NavNotificationService extends NotificationListenerService {
    private static final Set<String> APPS = new HashSet<>(Arrays.asList(
            "com.google.android.apps.maps",
            "com.waze"
    ));
    private String lastId = "";

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || !APPS.contains(sbn.getPackageName())) return;
        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return;

        Bundle e = n.extras;
        String title = txt(e.getCharSequence(Notification.EXTRA_TITLE));
        String text = txt(e.getCharSequence(Notification.EXTRA_TEXT));
        String big = txt(e.getCharSequence(Notification.EXTRA_BIG_TEXT));
        String sub = txt(e.getCharSequence(Notification.EXTRA_SUB_TEXT));
        String all = (title + " " + text + " " + big + " " + sub).trim();
        if (all.length() < 2) return;

        String distance = extractDistance(all);
        String direction = extractDirection(all);
        String street = extractStreet(all, distance);
        String source = sbn.getPackageName().contains("waze") ? "Waze" : "Maps";
        String id = direction + "|" + distance + "|" + street;
        if (id.equals(lastId)) return;
        lastId = id;
        NavSender.send(this, direction, distance, street, source);
    }

    private String txt(CharSequence c) { return c == null ? "" : c.toString(); }

    private String extractDistance(String s) {
        Matcher m = Pattern.compile("(\\d+[,.]?\\d*\\s?(?:m|km|ft|mi))", Pattern.CASE_INSENSITIVE).matcher(s);
        return m.find() ? m.group(1).replace('.', ',') : "";
    }

    private String extractDirection(String s) {
        String l = s.toLowerCase(Locale.ITALIAN);
        if (l.contains("rotonda") || l.contains("roundabout")) return "roundabout";
        if (l.contains("inversion") || l.contains("u-turn")) return "uturn";
        if (l.contains("sinistra") || l.contains("left")) return l.contains("legger") || l.contains("slight") ? "slight_left" : "left";
        if (l.contains("destra") || l.contains("right")) return l.contains("legger") || l.contains("slight") ? "slight_right" : "right";
        if (l.contains("continua") || l.contains("dritto") || l.contains("straight")) return "straight";
        return "straight";
    }

    private String extractStreet(String s, String dist) {
        String out = s;
        if (dist != null && dist.length() > 0) out = out.replace(dist, " ");
        out = out.replaceAll("(?i)tra|fra|svolta|gira|continua|prendi|mantieni|leggermente|a destra|a sinistra|su|verso|then|turn|right|left|onto|continue|take", " ");
        out = out.replaceAll("\\s+", " ").trim();
        if (out.length() > 42) out = out.substring(0, 42);
        return out.length() == 0 ? s : out;
    }
}
