Carlyle Arrow Phone v9 Accessibility experimental.
Reads Maps/Waze notifications plus visible screen text through Android Accessibility.
