package com.example.carlylearrow;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Handler;
import android.text.TextPaint;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ArrowView extends View {
    interface Listener {
        void onNextDemo();
        void onToggleSaver();
    }

    private final Paint arrowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dimArrowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final GestureDetector gestures;
    private final Handler handler = new Handler();
    private Instruction instruction;
    private boolean saverMode = false;
    private boolean dimScreen = false;
    private boolean gpsLinked = false;
    private boolean listenMode = false;
    private Listener listener;
    private long lastTouch = System.currentTimeMillis();

    private final Runnable dimmer = new Runnable() {
        @Override public void run() {
            if (saverMode && System.currentTimeMillis() - lastTouch > 25000) {
                dimScreen = true;
                invalidate();
            }
            handler.postDelayed(this, 5000);
        }
    };

    public ArrowView(Context context) {
        super(context);
        setFocusable(true);
        setKeepScreenOn(true);
        arrowPaint.setColor(Color.WHITE);
        arrowPaint.setStyle(Paint.Style.STROKE);
        arrowPaint.setStrokeCap(Paint.Cap.SQUARE);
        arrowPaint.setStrokeJoin(Paint.Join.MITER);
        dimArrowPaint.setColor(0xFF8A8A8A);
        dimArrowPaint.setStyle(Paint.Style.STROKE);
        dimArrowPaint.setStrokeCap(Paint.Cap.SQUARE);
        dimArrowPaint.setStrokeJoin(Paint.Join.ROUND);
        linePaint.setColor(0xFF333333);
        linePaint.setStrokeWidth(2f);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextAlign(Paint.Align.CENTER);
        gestures = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                wakeFromDim();
                if (!dimScreen && listener != null) listener.onNextDemo();
                return true;
            }
            @Override public void onLongPress(MotionEvent e) {
                wakeFromDim();
                if (listener != null) listener.onToggleSaver();
            }
        });
        handler.postDelayed(dimmer, 5000);
    }

    public void setListener(Listener listener) { this.listener = listener; }
    public void setInstruction(Instruction instruction) { this.instruction = instruction; invalidate(); }
    public void setSaverMode(boolean saverMode) { this.saverMode = saverMode; setKeepScreenOn(true); touch(); invalidate(); }
    public void setGpsLinked(boolean gpsLinked) { this.gpsLinked = gpsLinked; invalidate(); }
    public void setListenMode(boolean listenMode) { this.listenMode = listenMode; invalidate(); }

    private void touch() {
        lastTouch = System.currentTimeMillis();
        dimScreen = false;
    }

    private void wakeFromDim() {
        if (dimScreen) {
            touch();
            invalidate();
        }
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) touch();
        return gestures.onTouchEvent(event) || true;
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(Color.BLACK);
        if (dimScreen) {
            drawDim(canvas);
        } else {
            drawArrowScreen(canvas);
        }
    }

    private void drawDim(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        textPaint.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.NORMAL));
        textPaint.setColor(0xFFE0E0E0);
        textPaint.setTextSize(w * 0.22f);
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        String time = new SimpleDateFormat("H:mm", Locale.getDefault()).format(new Date());
        canvas.drawText(time, w / 2f, h * 0.43f - (fm.ascent + fm.descent) / 2f, textPaint);
        textPaint.setTextSize(w * 0.045f);
        textPaint.setColor(0xFFBDBDBD);
        String date = new SimpleDateFormat("EEEE | dd/MM/yy", Locale.ITALIAN).format(new Date()).toUpperCase(Locale.ITALIAN);
        canvas.drawText(date, w / 2f, h * 0.56f, textPaint);
        textPaint.setTextSize(w * 0.04f);
        textPaint.setColor(Color.WHITE);
        canvas.drawText("CARLYLE ARROW", w / 2f, h * 0.68f, textPaint);
        textPaint.setColor(gpsLinked ? 0xFF6DFF8A : 0xFFFFD166);
        canvas.drawText(gpsLinked ? "GPS agganciato" : "GPS in attesa", w / 2f, h * 0.76f, textPaint);
        textPaint.setColor(0xFF9E9E9E);
        textPaint.setTextSize(w * 0.035f);
        canvas.drawText("Tocca per tornare", w / 2f, h * 0.86f, textPaint);
    }

    private void drawArrowScreen(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        float cx = w / 2f;
        float top = h * 0.095f;
        // v13: simboli più piccoli e centrati nella parte alta: non devono uscire dallo schermo né coprire i metri.
        float arrowSize = w * 0.255f;
        arrowPaint.setStrokeWidth(Math.max(11f, w * 0.040f));
        dimArrowPaint.setStrokeWidth(Math.max(8f, w * 0.032f));
        Instruction ins = instruction == null ? new Instruction(Instruction.SLIGHT_RIGHT, "300 m", "Via Roma", "demo") : instruction;
        drawInstructionArrow(canvas, ins.type, cx, h * 0.275f, arrowSize);

        textPaint.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD));
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(w * 0.158f);
        canvas.drawText(ins.distance, cx, h * 0.585f, textPaint);

        textPaint.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.NORMAL));
        textPaint.setTextSize(w * 0.076f);
        drawMultilineCentered(canvas, ins.street, cx, h * 0.705f, w * 0.86f, textPaint, 2);

        textPaint.setTextSize(w * 0.047f);
        textPaint.setColor(0xFFBDBDBD);
        String mode = listenMode ? "in ascolto Maps/Waze" : "demo: tap cambia svolta";
        canvas.drawText(mode, cx, h * 0.88f, textPaint);
        textPaint.setTextSize(w * 0.038f);
        textPaint.setColor(gpsLinked ? 0xFF6DFF8A : 0xFFFFD166);
        canvas.drawText(gpsLinked ? "GPS agganciato" : "GPS in attesa", cx, h * 0.945f, textPaint);
    }

    private void drawInstructionArrow(Canvas canvas, int type, float cx, float cy, float s) {
        if (type == Instruction.LEFT || type == Instruction.SLIGHT_LEFT) {
            canvas.save(); canvas.scale(-1, 1, cx, cy); drawRightLike(canvas, cx, cy, s, type == Instruction.SLIGHT_LEFT); canvas.restore();
        } else if (type == Instruction.RIGHT || type == Instruction.SLIGHT_RIGHT) {
            drawRightLike(canvas, cx, cy, s, type == Instruction.SLIGHT_RIGHT);
        } else if (type == Instruction.UTURN) {
            drawUTurn(canvas, cx, cy, s);
        } else if (type == Instruction.ARRIVE) {
            drawArrive(canvas, cx, cy, s);
        } else {
            drawStraight(canvas, cx, cy, s);
        }
    }

    private void drawStraight(Canvas c, float cx, float cy, float s) {
        Path p = new Path();
        p.moveTo(cx, cy + s * 0.45f); p.lineTo(cx, cy - s * 0.28f);
        c.drawPath(p, arrowPaint);
        drawHead(c, cx, cy - s * 0.42f, 0, s);
    }

    private void drawRightLike(Canvas c, float cx, float cy, float s, boolean slight) {
        Path gray = new Path();
        gray.moveTo(cx - s * 0.18f, cy + s * 0.43f);
        gray.cubicTo(cx - s * 0.18f, cy + s * 0.05f, cx - s * 0.33f, cy - s * 0.15f, cx - s * 0.46f, cy - s * 0.26f);
        c.drawPath(gray, dimArrowPaint);
        Path p = new Path();
        p.moveTo(cx, cy + s * 0.43f);
        if (slight) p.cubicTo(cx, cy + s * 0.10f, cx + s * 0.10f, cy - s * 0.12f, cx + s * 0.34f, cy - s * 0.32f);
        else {
            p.lineTo(cx, cy - s * 0.08f);
            p.quadTo(cx, cy - s * 0.32f, cx + s * 0.24f, cy - s * 0.32f);
            p.lineTo(cx + s * 0.39f, cy - s * 0.32f);
        }
        c.drawPath(p, arrowPaint);
        drawHead(c, cx + s * 0.45f, cy - s * 0.32f, 90, s);
    }

    private void drawUTurn(Canvas c, float cx, float cy, float s) {
        RectF r = new RectF(cx - s * 0.35f, cy - s * 0.42f, cx + s * 0.20f, cy + s * 0.12f);
        c.drawArc(r, 90, -260, false, arrowPaint);
        Path p = new Path(); p.moveTo(cx + s * 0.20f, cy + s * 0.12f); p.lineTo(cx + s * 0.20f, cy + s * 0.43f); c.drawPath(p, arrowPaint);
        drawHead(c, cx - s * 0.31f, cy - s * 0.16f, 180, s);
    }

    private void drawArrive(Canvas c, float cx, float cy, float s) {
        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG); fill.setColor(Color.WHITE); fill.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy - s * 0.1f, s * 0.16f, fill);
        arrowPaint.setStrokeWidth(Math.max(12f, s * 0.06f));
        c.drawLine(cx, cy + s * 0.42f, cx, cy + s * 0.08f, arrowPaint);
    }

    private void drawHead(Canvas c, float x, float y, float deg, float s) {
        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG); fill.setColor(Color.WHITE); fill.setStyle(Paint.Style.FILL);
        Path head = new Path();
        float a = s * 0.135f;
        head.moveTo(0, -a); head.lineTo(a * 0.85f, a * 0.75f); head.lineTo(0, a * 0.35f); head.lineTo(-a * 0.85f, a * 0.75f); head.close();
        c.save(); c.translate(x, y); c.rotate(deg); c.drawPath(head, fill); c.restore();
    }

    private void drawMultilineCentered(Canvas c, String text, float cx, float y, float maxWidth, TextPaint p, int maxLines) {
        if (text == null) text = "";
        String[] words = text.split(" ");
        String line = "";
        int lines = 0;
        float lineHeight = p.getTextSize() * 1.08f;
        for (String word : words) {
            String test = line.length() == 0 ? word : line + " " + word;
            if (p.measureText(test) > maxWidth && line.length() > 0) {
                c.drawText(line, cx, y + lines * lineHeight, p);
                lines++;
                line = word;
                if (lines >= maxLines - 1) break;
            } else line = test;
        }
        if (line.length() > 0 && lines < maxLines) c.drawText(line, cx, y + lines * lineHeight, p);
    }
}
