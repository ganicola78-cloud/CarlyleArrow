package com.example.carlylearrow;

import android.content.SharedPreferences;
import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.DataMapItem;
import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.WearableListenerService;

public class NavWearService extends WearableListenerService {
    static final String PREF = "nav";
    static final String PATH_DATA = "/carlyle_arrow/nav";
    static final String PATH_MSG = "/carlyle_arrow/navmsg";

    @Override public void onMessageReceived(MessageEvent event) {
        if (event == null || event.getPath() == null) return;
        if (!PATH_MSG.equals(event.getPath())) return;
        try {
            String msg = new String(event.getData(), "UTF-8");
            String[] parts = msg.split("\\|", -1);
            String direction = parts.length > 0 ? parts[0] : "straight";
            String distance = parts.length > 1 ? parts[1] : "";
            String street = parts.length > 2 ? parts[2] : "";
            String source = parts.length > 3 ? parts[3] : "PHONE";
            save(direction, distance, street, source, msg);
        } catch(Exception ignored) {}
    }

    @Override public void onDataChanged(DataEventBuffer events) {
        for (DataEvent event : events) {
            try {
                if (event.getType() == DataEvent.TYPE_CHANGED && event.getDataItem() != null && event.getDataItem().getUri() != null && PATH_DATA.equals(event.getDataItem().getUri().getPath())) {
                    DataMap map = DataMapItem.fromDataItem(event.getDataItem()).getDataMap();
                    String direction = map.getString("direction", "straight");
                    String distance = map.getString("distance", "");
                    String street = map.getString("street", "");
                    String source = map.getString("source", "PHONE");
                    String id = map.getString("id", direction + "|" + distance + "|" + street + "|" + source + "|" + System.currentTimeMillis());
                    save(direction, distance, street, source, id);
                }
            } catch(Exception ignored) {}
        }
    }

    private void save(String direction, String distance, String street, String source, String id) {
        SharedPreferences sp = getSharedPreferences(PREF, MODE_PRIVATE);
        sp.edit()
            .putString("id", id == null ? String.valueOf(System.currentTimeMillis()) : id)
            .putString("direction", direction == null ? "straight" : direction)
            .putString("distance", distance == null ? "" : distance)
            .putString("street", street == null ? "" : street)
            .putString("source", source == null ? "PHONE" : source)
            .putLong("ts", System.currentTimeMillis())
            .apply();
    }
}
