Carlyle Arrow Watch v14 - simboli compatti: frecce ridotte e separate dalla distanza.
