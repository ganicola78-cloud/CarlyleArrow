package com.example.carlylearrow;

class Instruction {
    static final int STRAIGHT = 0;
    static final int RIGHT = 1;
    static final int LEFT = 2;
    static final int SLIGHT_RIGHT = 3;
    static final int SLIGHT_LEFT = 4;
    static final int UTURN = 5;
    static final int ARRIVE = 6;

    final int type;
    final String distance;
    final String street;
    final String sub;

    Instruction(int type, String distance, String street, String sub) {
        this.type = type;
        this.distance = distance;
        this.street = street;
        this.sub = sub;
    }
}
