package com.example.carlylearrow;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.content.Context;
import android.graphics.*;
import android.view.*;
import android.view.Window;
import android.view.WindowManager;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    ArrowView view;
    Vibrator vibrator;
    Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        vibrator = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
        view = new ArrowView(this, () -> vibrate());
        setContentView(view);
    }

    void vibrate() { try { if (vibrator != null) vibrator.vibrate(160); } catch(Exception ignored){} }

    public static class ArrowView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Runnable onInstructionChanged;
        int demo = -1;
        boolean waiting = true;
        boolean dim = false;
        long lastInteraction = System.currentTimeMillis();
        Handler handler = new Handler(Looper.getMainLooper());
        String direction="straight", distance="", street="In attesa dati telefono", source="Carlyle Arrow";
        String[][] demos={
                {"right","300 m","Via Roma","DEMO"},
                {"left","150 m","Wall St","DEMO"},
                {"straight","1,4 km","Continua dritto","DEMO"},
                {"slight_right","2,8 km","D1 Quai de Clichy","DEMO"},
                {"uturn","80 m","Inversione","DEMO"}
        };

        public ArrowView(Context c, Runnable vib){ super(c); onInstructionChanged=vib; setBackgroundColor(Color.BLACK); setFocusable(true); setClickable(true);
            setOnClickListener(v -> { if(dim){ dim=false; touch(); invalidate(); return; } demo=(demo+1)%demos.length; setInstruction(demos[demo][0], demos[demo][1], demos[demo][2], demos[demo][3], false); });
            setOnLongClickListener(v -> { dim=!dim; touch(); invalidate(); return true; });
            handler.postDelayed(ticker, 1000);
        }
        Runnable ticker = new Runnable(){ public void run(){ if(!dim && System.currentTimeMillis()-lastInteraction>30000){ dim=true; invalidate(); } else if(dim) invalidate(); handler.postDelayed(this,1000);} };
        void touch(){ lastInteraction=System.currentTimeMillis(); }
        public void setInstruction(String d,String dist,String st,String src,boolean w){ direction=d; distance=dist; street=st; source=src; waiting=w; dim=false; touch(); if(onInstructionChanged!=null && !w) onInstructionChanged.run(); invalidate(); }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){ if(e.getAction()==MotionEvent.ACTION_DOWN) touch(); return super.onTouchEvent(e); }

        @Override protected void onDraw(Canvas c){ super.onDraw(c); if(dim){ drawDim(c); return; } int w=getWidth(), h=getHeight(); float cx=w/2f;
            p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(22); p.setStrokeCap(Paint.Cap.SQUARE); p.setStrokeJoin(Paint.Join.ROUND);
            c.save(); c.translate(cx, h*0.27f); drawArrow(c, direction); c.restore();
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
            if(waiting){ p.setTextSize(25); c.drawText("In attesa", cx, h*0.55f, p); }
            else { p.setTextSize(48); c.drawText(distance, cx, h*0.57f, p); }
            p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)); p.setTextSize(waiting?24:29); p.setColor(Color.WHITE);
            drawMultiline(c, street, cx, h*0.70f, w*0.82f, 34);
            p.setTextSize(16); p.setColor(Color.LTGRAY); c.drawText(waiting?"Tap: demo  •  Pressione lunga: risparmio":source, cx, h-18, p);
        }

        void drawDim(Canvas c){ int w=getWidth(), h=getHeight(); float cx=w/2f; c.drawColor(Color.BLACK); p.setTextAlign(Paint.Align.CENTER); p.setStyle(Paint.Style.FILL);
            p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)); p.setColor(Color.rgb(190,190,190)); p.setTextSize(62);
            String time=new SimpleDateFormat("HH:mm", Locale.ITALIAN).format(new Date()); c.drawText(time,cx,h*0.38f,p);
            p.setTextSize(18); p.setColor(Color.rgb(150,150,150)); String date=new SimpleDateFormat("EEEE | dd/MM/yy", Locale.ITALIAN).format(new Date()).toUpperCase(Locale.ITALIAN); c.drawText(date,cx,h*0.49f,p);
            p.setTextSize(20); p.setColor(Color.WHITE); c.drawText("Carlyle Arrow",cx,h*0.62f,p);
            p.setTextSize(16); p.setColor(Color.LTGRAY); c.drawText(waiting?"In attesa dati telefono":"Navigazione attiva",cx,h*0.70f,p); c.drawText("Tocca per tornare",cx,h*0.82f,p);
        }

        void drawArrow(Canvas c,String d){ Path path=new Path();
            if (d.contains("left")) { path.moveTo(55,-40); path.lineTo(-35,-40); path.lineTo(-35,35); path.moveTo(-35,-40); path.lineTo(-5,-72); path.moveTo(-35,-40); path.lineTo(-5,-8); }
            else if (d.contains("uturn")) { path.moveTo(38,60); path.lineTo(38,-25); path.quadTo(38,-75,-15,-75); path.lineTo(-45,-75); path.moveTo(-45,-75); path.lineTo(-15,-105); path.moveTo(-45,-75); path.lineTo(-15,-45); }
            else if (d.contains("slight")) { path.moveTo(-15,75); path.lineTo(-15,-10); path.quadTo(-15,-55,35,-75); path.moveTo(35,-75); path.lineTo(5,-88); path.moveTo(35,-75); path.lineTo(20,-43); }
            else if (d.contains("right")) { path.moveTo(-45,65); path.lineTo(-45,-20); path.quadTo(-45,-55,12,-55); path.lineTo(55,-55); path.moveTo(55,-55); path.lineTo(25,-85); path.moveTo(55,-55); path.lineTo(25,-25); }
            else { path.moveTo(0,70); path.lineTo(0,-75); path.moveTo(0,-75); path.lineTo(-35,-38); path.moveTo(0,-75); path.lineTo(35,-38); }
            c.drawPath(path,p);
        }
        void drawMultiline(Canvas c,String text,float x,float y,float maxW,float lineH){ if(text==null)text=""; String[] words=text.split(" "); String line=""; int count=0; for(String word:words){ String test=line.length()==0?word:line+" "+word; if(p.measureText(test)>maxW && line.length()>0){ c.drawText(line,x,y+count*lineH,p); line=word; count++; } else line=test; if(count>=2) break; } if(count<3)c.drawText(line,x,y+count*lineH,p); }
    }
}
