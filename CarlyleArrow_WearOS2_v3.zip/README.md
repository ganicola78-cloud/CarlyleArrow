Carlyle Arrow Wear OS 2 v3 - versione stabile semplificata: freccia demo, schermata attesa dati telefono, risparmio interno.
