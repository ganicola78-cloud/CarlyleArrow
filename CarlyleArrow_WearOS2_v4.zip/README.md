Carlyle Arrow Wear OS2 v4 - ricezione dati da phone companion via Wearable Data Layer.
