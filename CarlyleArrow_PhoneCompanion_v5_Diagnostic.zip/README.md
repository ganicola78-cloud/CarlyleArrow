Carlyle Arrow Phone Companion v3

Correzione build: AndroidX abilitato. Legge notifiche Google Maps/Waze e invia istruzioni a Carlyle Arrow via Wearable Data Layer.
