Carlyle Arrow Watch v7

Modifica vibrazione:
- non vibra più a ogni aggiornamento della notifica Maps/Waze;
- vibra solo una volta quando la distanza alla manovra scende sotto 100 m;
- vibra una seconda volta quando scende sotto 10 m;
- quando cambia manovra/strada, le soglie vengono azzerate.
