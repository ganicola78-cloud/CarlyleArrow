package com.example.carlylearrow;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.google.android.gms.wearable.DataClient;
import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.DataMapItem;
import com.google.android.gms.wearable.MessageClient;
import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.Wearable;

public class MainActivity extends Activity implements DataClient.OnDataChangedListener, MessageClient.OnMessageReceivedListener {
    MotoArrowView view;
    Vibrator vibrator;
    Handler handler = new Handler(Looper.getMainLooper());
    String lastSavedId = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        vibrator = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
        view = new MotoArrowView(this, () -> vibrate());
        setContentView(view);
        handler.postDelayed(savedPoller, 700);
    }

    @Override protected void onStart() {
        super.onStart();
        try { Wearable.getDataClient(this).addListener(this); } catch(Exception ignored){}
        try { Wearable.getMessageClient(this).addListener(this); } catch(Exception ignored){}
    }

    @Override protected void onStop() {
        try { Wearable.getDataClient(this).removeListener(this); } catch(Exception ignored){}
        try { Wearable.getMessageClient(this).removeListener(this); } catch(Exception ignored){}
        super.onStop();
    }

    @Override public void onDataChanged(DataEventBuffer events) {
        for (DataEvent event : events) {
            if (event.getType() == DataEvent.TYPE_CHANGED && event.getDataItem() != null && event.getDataItem().getUri() != null && "/carlyle_arrow/nav".equals(event.getDataItem().getUri().getPath())) {
                DataMap map = DataMapItem.fromDataItem(event.getDataItem()).getDataMap();
                final String direction = map.getString("direction", "straight");
                final String distance = map.getString("distance", "");
                final String street = map.getString("street", "");
                final String source = map.getString("source", "PHONE");
                runOnUiThread(() -> { if (view != null) view.setInstruction(direction, distance, street, source, false); });
            }
        }
    }

    @Override public void onMessageReceived(MessageEvent event) {
        if (event == null || event.getPath() == null) return;
        if (!"/carlyle_arrow/navmsg".equals(event.getPath())) return;
        try {
            String msg = new String(event.getData());
            String[] parts = msg.split("\\|", -1);
            final String direction = parts.length > 0 ? parts[0] : "straight";
            final String distance = parts.length > 1 ? parts[1] : "";
            final String street = parts.length > 2 ? parts[2] : "";
            final String source = parts.length > 3 ? parts[3] : "PHONE";
            runOnUiThread(() -> { if (view != null) view.setInstruction(direction, distance, street, source, false); });
        } catch(Exception ignored){}
    }

    Runnable savedPoller = new Runnable() { public void run() {
        try {
            SharedPreferences sp = getSharedPreferences("nav", MODE_PRIVATE);
            String id = sp.getString("id", "");
            if (id != null && id.length() > 0 && !id.equals(lastSavedId)) {
                lastSavedId = id;
                final String direction = sp.getString("direction", "straight");
                final String distance = sp.getString("distance", "");
                final String street = sp.getString("street", "");
                final String source = sp.getString("source", "PHONE");
                if (view != null) view.setInstruction(direction, distance, street, source, false);
            }
        } catch(Exception ignored) {}
        handler.postDelayed(this, 700);
    }};

    void vibrate() { try { if (vibrator != null) vibrator.vibrate(160); } catch(Exception ignored){} }

    public static class MotoArrowView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Runnable onInstructionChanged;
        Handler handler = new Handler(Looper.getMainLooper());
        Context appContext;
        int demo = -1;
        boolean waiting = true;
        boolean dim = false;
        long lastInteraction = System.currentTimeMillis();
        String direction = "straight";
        String distance = "";
        String street = "In attesa dati telefono";
        String source = "Carlyle Arrow";
        String lastVibrationKey = "";
        boolean vibratedAt100 = false;
        boolean vibratedAt10 = false;
        boolean vibrationEnabled = true;
        String toastText = "";
        long toastUntil = 0;

        String[][] demos = {
            {"straight", "300 m", "Procedi verso Via Roma", "DEMO"},
            {"right", "100 m", "Svolta a destra", "DEMO"},
            {"left", "150 m", "Svolta a sinistra", "DEMO"},
            {"slight_right", "250 m", "Mantieni la destra", "DEMO"},
            {"slight_left", "250 m", "Mantieni la sinistra", "DEMO"},
            {"roundabout", "80 m", "Alla rotonda, prendi la 2ª uscita", "DEMO"},
            {"uturn", "50 m", "Inversione a U", "DEMO"},
            {"arrive", "", "Destinazione", "DEMO"}
        };

        public MotoArrowView(Context c, Runnable vib) {
            super(c);
            appContext = c.getApplicationContext();
            onInstructionChanged = vib;
            setBackgroundColor(Color.BLACK);
            setFocusable(true);
            setClickable(true);
            try { vibrationEnabled = appContext.getSharedPreferences("settings", Context.MODE_PRIVATE).getBoolean("vibration_enabled", true); } catch(Exception ignored){}
            setOnClickListener(v -> {
                if (dim) { dim = false; touch(); invalidate(); return; }
                demo = (demo + 1) % demos.length;
                setInstruction(demos[demo][0], demos[demo][1], demos[demo][2], demos[demo][3], false);
            });
            setOnLongClickListener(v -> { toggleVibration(); touch(); invalidate(); return true; });
            handler.postDelayed(ticker, 1000);
        }

        Runnable ticker = new Runnable(){ public void run(){
            if(!dim && System.currentTimeMillis() - lastInteraction > 30000){ dim = true; invalidate(); }
            else if(dim) invalidate();
            handler.postDelayed(this,1000);
        }};

        void touch(){ lastInteraction = System.currentTimeMillis(); }

        public void setInstruction(String d, String dist, String st, String src, boolean w) {
            direction = d == null ? "straight" : d;
            distance = dist == null ? "" : dist;
            street = st == null ? "" : st;
            source = src == null ? "PHONE" : src;
            waiting = w;
            dim = false;
            touch();
            if (onInstructionChanged != null && !w && shouldVibrateForInstruction(direction, distance, street)) onInstructionChanged.run();
            invalidate();
        }

        void toggleVibration(){
            vibrationEnabled = !vibrationEnabled;
            try { appContext.getSharedPreferences("settings", Context.MODE_PRIVATE).edit().putBoolean("vibration_enabled", vibrationEnabled).apply(); } catch(Exception ignored){}
            toastText = vibrationEnabled ? "Vibrazione ON" : "Vibrazione OFF";
            toastUntil = System.currentTimeMillis() + 2200;
        }

        boolean shouldVibrateForInstruction(String d, String dist, String st){
            if(!vibrationEnabled) return false;
            String key = normalize(d) + "|" + normalize(st);
            if(!key.equals(lastVibrationKey)){
                lastVibrationKey = key;
                vibratedAt100 = false;
                vibratedAt10 = false;
            }
            int meters = parseMeters(dist);
            if(meters < 0) return false;
            if(meters <= 10 && !vibratedAt10){
                vibratedAt10 = true;
                vibratedAt100 = true;
                return true;
            }
            if(meters <= 100 && !vibratedAt100){
                vibratedAt100 = true;
                return true;
            }
            return false;
        }

        String normalize(String s){ return s == null ? "" : s.trim().toLowerCase(Locale.ITALIAN).replaceAll("\\s+", " "); }

        int parseMeters(String s){
            if(s == null) return -1;
            String t = s.trim().toLowerCase(Locale.ITALIAN);
            if(t.length() == 0) return -1;
            boolean km = t.contains("km");
            t = t.replace("chilometri", "km").replace("chilometro", "km").replace("metri", "m").replace("metro", "m");
            StringBuilder num = new StringBuilder();
            for(int i=0;i<t.length();i++){
                char ch=t.charAt(i);
                if((ch>='0'&&ch<='9') || ch==',' || ch=='.') num.append(ch);
                else if(num.length()>0) break;
            }
            if(num.length()==0) return -1;
            try{
                double v = Double.parseDouble(num.toString().replace(',', '.'));
                if(km) v *= 1000.0;
                return (int)Math.round(v);
            } catch(Exception e){ return -1; }
        }

        @Override public boolean onTouchEvent(MotionEvent e) { if(e.getAction()==MotionEvent.ACTION_DOWN) touch(); return super.onTouchEvent(e); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            if(dim){ drawDim(c); return; }
            int w = getWidth(), h = getHeight();
            float cx = w / 2f;
            c.drawColor(Color.BLACK);

            p.setColor(Color.WHITE);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(18f, w * 0.07f));
            p.setStrokeCap(Paint.Cap.SQUARE);
            p.setStrokeJoin(Paint.Join.ROUND);
            c.save();
            c.translate(cx, h * 0.30f);
            drawManeuverSymbol(c, direction, street, Math.min(w, h) * 0.80f);
            c.restore();

            p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
            p.setColor(Color.WHITE);
            if(waiting){
                p.setTextSize(w * 0.105f);
                c.drawText("IN ATTESA", cx, h * 0.62f, p);
            } else {
                p.setTextSize(w * 0.205f);
                String d = distance == null || distance.length() == 0 ? "—" : distance;
                c.drawText(d, cx, h * 0.64f, p);
            }

            p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL));
            p.setTextSize(w * 0.060f);
            p.setColor(0xFFEAEAEA);
            drawSmallText(c, street, cx, h * 0.76f, w * 0.78f, w * 0.070f, 2);

            p.setTextSize(w * 0.038f);
            p.setColor(Color.LTGRAY);
            String bottom = waiting ? "Tap: demo • Lungo: vibrazione" : source + (vibrationEnabled ? "" : " • VIB OFF");
            c.drawText(bottom, cx, h - 15, p);
            drawToastIfNeeded(c, w, h, cx);
        }

        void drawToastIfNeeded(Canvas c, int w, int h, float cx){
            if(toastText == null || toastText.length() == 0 || System.currentTimeMillis() > toastUntil) return;
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(40,40,40));
            RectF box = new RectF(w*0.12f, h*0.08f, w*0.88f, h*0.19f);
            c.drawRoundRect(box, 18, 18, p);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
            p.setTextSize(w * 0.065f);
            p.setColor(Color.WHITE);
            c.drawText(toastText, cx, h*0.155f, p);
        }

        void drawDim(Canvas c){
            int w=getWidth(), h=getHeight(); float cx=w/2f; c.drawColor(Color.BLACK); p.setTextAlign(Paint.Align.CENTER); p.setStyle(Paint.Style.FILL);
            p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)); p.setColor(Color.rgb(190,190,190)); p.setTextSize(w * 0.22f);
            String time=new SimpleDateFormat("HH:mm", Locale.ITALIAN).format(new Date()); c.drawText(time,cx,h*0.38f,p);
            p.setTextSize(w * 0.05f); p.setColor(Color.rgb(150,150,150)); String date=new SimpleDateFormat("EEEE | dd/MM/yy", Locale.ITALIAN).format(new Date()).toUpperCase(Locale.ITALIAN); c.drawText(date,cx,h*0.49f,p);
            p.setTextSize(w * 0.055f); p.setColor(Color.WHITE); c.drawText("Carlyle Arrow",cx,h*0.62f,p);
            p.setTextSize(w * 0.043f); p.setColor(Color.LTGRAY); c.drawText(waiting?"In attesa dati telefono":"Navigazione attiva",cx,h*0.70f,p); c.drawText(vibrationEnabled?"Vibrazione ON":"Vibrazione OFF",cx,h*0.76f,p); c.drawText("Tocca per tornare",cx,h*0.84f,p);
        }

        void drawManeuverSymbol(Canvas c, String rawDir, String rawStreet, float size){
            String d = rawDir == null ? "straight" : rawDir.toLowerCase(Locale.ITALIAN);
            String st = rawStreet == null ? "" : rawStreet.toLowerCase(Locale.ITALIAN);
            if(d.contains("roundabout") || st.contains("rotonda") || st.contains("rotatoria") || st.contains("roundabout")) { drawRoundabout(c, rawStreet, size); return; }
            if(d.contains("arrive") || st.contains("destinazione") || st.contains("arrivo")) { drawArrive(c, size); return; }
            if(d.contains("uturn") || st.contains("inversion")) { drawUTurn(c, size); return; }
            if(d.contains("slight_left") || st.contains("mantieni la sinistra") || st.contains("keep left")) { drawFork(c, size, false); return; }
            if(d.contains("slight_right") || st.contains("mantieni la destra") || st.contains("keep right")) { drawFork(c, size, true); return; }
            if(d.contains("left") || st.contains("sinistra")) { drawLeft(c, size); return; }
            if(d.contains("right") || st.contains("destra")) { drawRight(c, size); return; }
            drawStraight(c, size);
        }

        void drawStraight(Canvas c, float s){
            Path path = new Path();
            path.moveTo(0, s * 0.30f); path.lineTo(0, -s * 0.25f);
            c.drawPath(path, p);
            drawHead(c, 0, -s * 0.36f, 0, s * 0.72f);
        }

        void drawRight(Canvas c, float s){
            Path path = new Path();
            path.moveTo(-s * 0.16f, s * 0.32f);
            path.lineTo(-s * 0.16f, -s * 0.05f);
            path.quadTo(-s * 0.16f, -s * 0.27f, s * 0.08f, -s * 0.27f);
            path.lineTo(s * 0.26f, -s * 0.27f);
            c.drawPath(path, p);
            drawHead(c, s * 0.34f, -s * 0.27f, 90, s * 0.72f);
        }

        void drawLeft(Canvas c, float s){
            c.save(); c.scale(-1, 1); drawRight(c, s); c.restore();
        }

        void drawFork(Canvas c, float s, boolean right){
            Paint old = new Paint(p);
            p.setStrokeWidth(Math.max(10f, s * 0.040f));
            p.setColor(0xFF777777);
            Path base = new Path();
            base.moveTo(0, s * 0.34f); base.lineTo(0, -s * 0.24f);
            c.drawPath(base, p);
            p.setColor(Color.WHITE);
            p.setStrokeWidth(Math.max(18f, s * 0.070f));
            Path branch = new Path();
            branch.moveTo(0, s * 0.34f);
            branch.lineTo(0, s * 0.02f);
            if(right) branch.quadTo(0, -s * 0.18f, s * 0.26f, -s * 0.33f);
            else branch.quadTo(0, -s * 0.18f, -s * 0.26f, -s * 0.33f);
            c.drawPath(branch, p);
            drawHead(c, right ? s * 0.32f : -s * 0.32f, -s * 0.36f, right ? 45 : -45, s * 0.66f);
            p = old;
        }

        void drawUTurn(Canvas c, float s){
            RectF r = new RectF(-s * 0.34f, -s * 0.34f, s * 0.20f, s * 0.20f);
            c.drawArc(r, 90, -265, false, p);
            Path tail = new Path();
            tail.moveTo(s * 0.20f, s * 0.20f); tail.lineTo(s * 0.20f, s * 0.36f);
            c.drawPath(tail, p);
            drawHead(c, -s * 0.34f, -s * 0.10f, 180, s * 0.70f);
        }

        void drawRoundabout(Canvas c, String txt, float s){
            int exit = parseExitNumber(txt);
            float r = s * 0.18f;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(16f, s * 0.060f));
            RectF oval = new RectF(-r, -r, r, r);
            c.drawArc(oval, 135, 315, false, p);
            drawHead(c, r * 0.92f, -r * 0.55f, 45, s * 0.50f);
            if(exit > 0){
                p.setStyle(Paint.Style.FILL);
                p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
                p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(s * 0.20f);
                c.drawText(String.valueOf(exit), 0, s * 0.065f, p);
            }
        }

        void drawArrive(Canvas c, float s){
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(0, -s * 0.10f, s * 0.09f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(14f, s * 0.050f));
            c.drawLine(0, s * 0.32f, 0, -s * 0.02f, p);
        }

        void drawHead(Canvas c, float x, float y, float deg, float s){
            Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG); fill.setColor(Color.WHITE); fill.setStyle(Paint.Style.FILL);
            Path head = new Path();
            float a = Math.max(30f, s * 0.19f);
            head.moveTo(0, -a); head.lineTo(a * 0.85f, a * 0.75f); head.lineTo(0, a * 0.35f); head.lineTo(-a * 0.85f, a * 0.75f); head.close();
            c.save(); c.translate(x, y); c.rotate(deg); c.drawPath(head, fill); c.restore();
        }

        int parseExitNumber(String s){
            if(s == null) return 0;
            String l = s.toLowerCase(Locale.ITALIAN);
            Matcher m = Pattern.compile("(\\d+)\\s*(?:ª|a|°)?\\s*(?:uscita|exit)").matcher(l);
            if(m.find()) { try { return Integer.parseInt(m.group(1)); } catch(Exception ignored){} }
            m = Pattern.compile("(?:uscita|exit)\\s*(\\d+)").matcher(l);
            if(m.find()) { try { return Integer.parseInt(m.group(1)); } catch(Exception ignored){} }
            return 0;
        }

        void drawSmallText(Canvas c, String text, float x, float y, float maxW, float lineH, int maxLines){
            if(text == null) text = "";
            text = text.trim();
            if(text.length() == 0) return;
            String[] words = text.split(" ");
            String line = "";
            int count = 0;
            for(String word : words){
                String test = line.length() == 0 ? word : line + " " + word;
                if(p.measureText(test) > maxW && line.length() > 0){
                    c.drawText(line, x, y + count * lineH, p);
                    line = word;
                    count++;
                    if(count >= maxLines) return;
                } else line = test;
            }
            if(count < maxLines) c.drawText(line, x, y + count * lineH, p);
        }
    }
}
