Carlyle Arrow Watch v12 - Moto Symbols Fit

Riduce dimensione frecce per display rotondo Carlyle, mantiene modalità moto, vibrazione 100/10 e toggle vibrazione.
