# Carlyle Arrow v1

Prima versione demo per Fossil Carlyle / Wear OS 2: schermata nera con freccia bianca grande e istruzioni stile navigazione.

- Tap: cambia istruzione demo
- Pressione prolungata: cambia sempre acceso / risparmio
- Può ricevere aggiornamenti demo via broadcast mentre è aperta.
