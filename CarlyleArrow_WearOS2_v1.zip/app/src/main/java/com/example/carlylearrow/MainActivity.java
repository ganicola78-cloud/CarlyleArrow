package com.example.carlylearrow;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity implements ArrowView.Listener {
    public static final String ACTION_UPDATE = "com.example.carlylearrow.UPDATE";
    private ArrowView view;
    private int index = 0;
    private boolean saver = false;
    private final Instruction[] demo = new Instruction[] {
            new Instruction(Instruction.SLIGHT_RIGHT, "1,4 km", "D1 Quai de Clichy", "demo"),
            new Instruction(Instruction.LEFT, "150 m", "Rue du Commandant Marceau", "demo"),
            new Instruction(Instruction.RIGHT, "300 m", "Via Roma", "demo"),
            new Instruction(Instruction.STRAIGHT, "2,8 km", "Continua su D1", "demo"),
            new Instruction(Instruction.ARRIVE, "6 min", "Arrivo", "demo")
    };

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!ACTION_UPDATE.equals(intent.getAction())) return;
            int type = parseType(intent.getStringExtra("turn"));
            String distance = safe(intent.getStringExtra("distance"), "--");
            String street = safe(intent.getStringExtra("street"), "Indicazione ricevuta");
            String sub = safe(intent.getStringExtra("sub"), "Maps/Waze");
            view.setListenMode(true);
            view.setInstruction(new Instruction(type, distance, street, sub));
            vibrate(90);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        view = new ArrowView(this);
        view.setListener(this);
        view.setInstruction(demo[index]);
        view.setSaverMode(saver);
        setContentView(view);
    }

    @Override protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter(ACTION_UPDATE);
        registerReceiver(receiver, filter);
    }

    @Override protected void onPause() {
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
        super.onPause();
    }

    @Override public void onNextDemo() {
        index = (index + 1) % demo.length;
        view.setListenMode(false);
        view.setInstruction(demo[index]);
        vibrate(35);
    }

    @Override public void onToggleSaver() {
        saver = !saver;
        view.setSaverMode(saver);
        vibrate(120);
    }

    private int parseType(String turn) {
        if (turn == null) return Instruction.STRAIGHT;
        turn = turn.toLowerCase();
        if (turn.contains("slight_right") || turn.contains("leggera_destra") || turn.contains("slight right")) return Instruction.SLIGHT_RIGHT;
        if (turn.contains("slight_left") || turn.contains("leggera_sinistra") || turn.contains("slight left")) return Instruction.SLIGHT_LEFT;
        if (turn.contains("right") || turn.contains("destra")) return Instruction.RIGHT;
        if (turn.contains("left") || turn.contains("sinistra")) return Instruction.LEFT;
        if (turn.contains("uturn") || turn.contains("inversione")) return Instruction.UTURN;
        if (turn.contains("arrive") || turn.contains("arrivo")) return Instruction.ARRIVE;
        return Instruction.STRAIGHT;
    }

    private String safe(String s, String fallback) { return s == null || s.trim().isEmpty() ? fallback : s; }

    private void vibrate(long ms) {
        try {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) v.vibrate(ms);
        } catch (Exception ignored) {}
    }
}
