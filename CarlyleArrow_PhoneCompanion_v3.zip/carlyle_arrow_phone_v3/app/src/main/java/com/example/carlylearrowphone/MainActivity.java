package com.example.carlylearrowphone;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(32, 60, 32, 32);
        l.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("Carlyle Arrow Phone");
        title.setTextSize(26);
        title.setTextColor(0xff000000);
        l.addView(title);

        TextView info = new TextView(this);
        info.setText("Companion per Carlyle Arrow.\n\n1) Attiva Accesso notifiche.\n2) Avvia navigazione su Google Maps o Waze.\n3) Tieni aperta Carlyle Arrow sul Carlyle.\n\nUsa il tasto test per verificare il collegamento.");
        info.setTextSize(17);
        info.setPadding(0, 24, 0, 24);
        l.addView(info);

        Button btn = new Button(this);
        btn.setText("Apri Accesso notifiche");
        btn.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        l.addView(btn);

        Button test = new Button(this);
        test.setText("Invia test al Carlyle");
        test.setOnClickListener(v -> NavSender.send(this, "right", "300 m", "Via Roma", "TEST"));
        l.addView(test);

        setContentView(l);
    }
}
