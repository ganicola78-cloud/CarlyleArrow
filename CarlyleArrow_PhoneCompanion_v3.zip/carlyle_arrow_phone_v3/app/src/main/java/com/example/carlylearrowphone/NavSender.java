package com.example.carlylearrowphone;

import android.content.Context;
import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.PutDataMapRequest;
import com.google.android.gms.wearable.PutDataRequest;
import com.google.android.gms.wearable.Wearable;

public class NavSender {
    static void send(Context ctx, String direction, String distance, String street, String source) {
        PutDataMapRequest req = PutDataMapRequest.create("/carlyle_arrow/nav");
        DataMap m = req.getDataMap();
        m.putString("id", source + ":" + direction + ":" + distance + ":" + street + ":" + System.currentTimeMillis());
        m.putString("direction", direction == null ? "straight" : direction);
        m.putString("distance", distance == null ? "" : distance);
        m.putString("street", street == null ? "" : street);
        m.putString("source", source == null ? "" : source);
        m.putLong("ts", System.currentTimeMillis());
        PutDataRequest p = req.asPutDataRequest();
        p.setUrgent();
        Wearable.getDataClient(ctx).putDataItem(p);
    }
}
