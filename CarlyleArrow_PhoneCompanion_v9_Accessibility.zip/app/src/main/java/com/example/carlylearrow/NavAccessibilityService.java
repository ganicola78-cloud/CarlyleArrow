package com.example.carlylearrow;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NavAccessibilityService extends AccessibilityService {
    private static final Pattern DIST = Pattern.compile("(?i)^(\\d+[,.]?\\d*\\s?(m|km|ft|mi))$");
    private static final Pattern DIST_ANY = Pattern.compile("(?i)(\\d+[,.]?\\d*\\s?(m|km|ft|mi))");
    private long lastSentAt = 0L;
    private String lastId = "";

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String pkg = event.getPackageName().toString();
        if (!pkg.equals("com.google.android.apps.maps") && !pkg.equals("com.waze")) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        List<String> lines = new ArrayList<>();
        collect(root, lines, new HashSet<AccessibilityNodeInfo>());
        if (lines.size() == 0) return;

        Instruction ins = parse(lines, pkg.contains("waze") ? "Waze-A11Y" : "Maps-A11Y");
        if (ins == null) return;

        String id = ins.direction + "|" + ins.distance + "|" + ins.street + "|" + ins.source;
        long now = System.currentTimeMillis();
        if (id.equals(lastId) && now - lastSentAt < 2500) return;
        lastId = id;
        lastSentAt = now;
        NavSender.send(this, ins.direction, ins.distance, ins.street, ins.source);
    }

    @Override public void onInterrupt() { }

    private void collect(AccessibilityNodeInfo node, List<String> out, Set<AccessibilityNodeInfo> seen) {
        if (node == null || seen.contains(node)) return;
        seen.add(node);
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        addText(out, t);
        addText(out, d);
        for (int i = 0; i < node.getChildCount(); i++) collect(node.getChild(i), out, seen);
    }

    private void addText(List<String> out, CharSequence cs) {
        if (cs == null) return;
        String s = cs.toString().replace('\n', ' ').replaceAll("\\s+", " ").trim();
        if (s.length() < 2) return;
        // keep useful UI text, skip common controls/noise
        String l = s.toLowerCase(Locale.ITALIAN);
        if (l.equals("chiudi") || l.equals("cerca") || l.equals("x") || l.equals("prossime svolte") || l.equals("prossime segnalazioni")) return;
        if (!out.contains(s)) out.add(s);
    }

    private Instruction parse(List<String> lines, String source) {
        // 1) Prefer explicit instruction lines from Google Maps step list.
        for (int i = 0; i < lines.size(); i++) {
            String s = lines.get(i);
            if (isInstruction(s)) {
                String dist = nearestDistance(lines, i);
                String street = cleanInstruction(s);
                String dir = extractDirection(s);
                return new Instruction(dir, dist, street, source);
            }
        }

        // 2) Waze top card often exposes distance line followed by street name.
        for (int i = 0; i < lines.size(); i++) {
            String dist = exactDistance(lines.get(i));
            if (dist.length() > 0) {
                String next = nextUseful(lines, i + 1);
                if (next.length() > 0 && !isJunk(next)) {
                    String dir = extractDirection(next);
                    return new Instruction(dir, dist, shorten(next), source);
                }
            }
        }

        // 3) Last fallback: any line containing distance plus a place/street.
        for (String s : lines) {
            String dist = anyDistance(s);
            if (dist.length() > 0) {
                String street = shorten(s.replace(dist, " ").replaceAll("\\s+", " ").trim());
                if (street.length() > 0 && !isJunk(street)) return new Instruction(extractDirection(s), dist, street, source);
            }
        }
        return null;
    }

    private boolean isInstruction(String s) {
        String l = s.toLowerCase(Locale.ITALIAN);
        return l.contains("svolta") || l.contains("gira") || l.contains("procedi") || l.contains("continua") ||
               l.contains("mantieni") || l.contains("rotonda") || l.contains("rotatoria") || l.contains("esci dalla rotonda") ||
               l.contains("prendi") || l.contains("destinazione") || l.contains("arrivo") ||
               l.contains("turn") || l.contains("continue") || l.contains("roundabout") || l.contains("take") || l.contains("exit");
    }

    private String extractDirection(String s) {
        String l = s.toLowerCase(Locale.ITALIAN);
        if (l.contains("rotonda") || l.contains("rotatoria") || l.contains("roundabout")) return "roundabout";
        if (l.contains("inversion") || l.contains("u-turn")) return "uturn";
        if (l.contains("mantieni la sinistra") || l.contains("keep left")) return "slight_left";
        if (l.contains("mantieni la destra") || l.contains("keep right")) return "slight_right";
        if (l.contains("sinistra") || l.contains("left")) return (l.contains("legger") || l.contains("slight")) ? "slight_left" : "left";
        if (l.contains("destra") || l.contains("right")) return (l.contains("legger") || l.contains("slight")) ? "slight_right" : "right";
        if (l.contains("arrivo") || l.contains("destinazione") || l.contains("destination")) return "arrive";
        return "straight";
    }

    private String nearestDistance(List<String> lines, int idx) {
        for (int off = 1; off <= 3; off++) {
            int before = idx - off;
            if (before >= 0) {
                String d = exactDistance(lines.get(before));
                if (d.length() > 0) return d;
            }
            int after = idx + off;
            if (after < lines.size()) {
                String d = exactDistance(lines.get(after));
                if (d.length() > 0) return d;
            }
        }
        String d = anyDistance(lines.get(idx));
        return d;
    }

    private String exactDistance(String s) {
        Matcher m = DIST.matcher(s.trim());
        return m.find() ? m.group(1).replace('.', ',') : "";
    }

    private String anyDistance(String s) {
        Matcher m = DIST_ANY.matcher(s);
        return m.find() ? m.group(1).replace('.', ',') : "";
    }

    private String nextUseful(List<String> lines, int start) {
        for (int i = start; i < Math.min(lines.size(), start + 5); i++) {
            String s = lines.get(i);
            if (exactDistance(s).length() > 0) continue;
            if (isJunk(s)) continue;
            return s;
        }
        return "";
    }

    private boolean isJunk(String s) {
        String l = s.toLowerCase(Locale.ITALIAN);
        return l.contains("waze in funzione") || l.contains("clicca per aprire") || l.equals("waze") || l.equals("maps") ||
               l.contains("esci dalla navigazione") || l.contains("spegni") || l.contains("download completato") ||
               l.contains("prossime svolte") || l.contains("prossime segnalazioni") || l.contains("free") ||
               l.matches(".*\\d+\s?h\s?\\d+\s?min.*") || l.matches(".*\\d+\s?min.*\\d+\s?km.*");
    }

    private String cleanInstruction(String s) {
        String out = s;
        out = out.replaceAll("(?i)^e poi\\s+", "");
        out = out.replaceAll("(?i)^tra\\s+", "");
        out = out.replaceAll("\\s+", " ").trim();
        return shorten(out);
    }

    private String shorten(String s) {
        String out = s == null ? "" : s.trim();
        if (out.length() > 52) out = out.substring(0, 52).trim();
        return out;
    }

    static class Instruction {
        final String direction, distance, street, source;
        Instruction(String d, String dist, String st, String src) {
            direction = d == null ? "straight" : d;
            distance = dist == null ? "" : dist;
            street = st == null ? "" : st;
            source = src == null ? "" : src;
        }
    }
}
