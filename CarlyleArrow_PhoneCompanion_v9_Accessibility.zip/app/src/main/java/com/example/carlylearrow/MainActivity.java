package com.example.carlylearrow;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import java.util.List;

public class MainActivity extends Activity {
    TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(32, 52, 32, 32);
        l.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("Carlyle Arrow Phone v9");
        title.setTextSize(25);
        title.setTextColor(0xff000000);
        l.addView(title);

        TextView info = new TextView(this);
        info.setText("1) Tieni aperta Carlyle Arrow sul Carlyle.\n2) Controlla che Wear OS dica Connesso.\n3) Premi Diagnostica, poi Invia test. Se il Carlyle resta DEMO, controlla il testo sotto.\n\nPer Maps/Waze abilita Accesso notifiche.
Per leggere le schermate interne, abilita anche Accessibilità.");
        info.setTextSize(16);
        info.setPadding(0, 20, 0, 20);
        l.addView(info);

        Button diag = new Button(this);
        diag.setText("Diagnostica Carlyle");
        diag.setOnClickListener(v -> runDiagnostic());
        l.addView(diag);

        Button btn = new Button(this);
        btn.setText("Apri Accesso notifiche");
        btn.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        l.addView(btn);

        Button acc = new Button(this);
        acc.setText("Apri Accessibilità");
        acc.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        l.addView(acc);

        Button test = new Button(this);
        test.setText("Invia test al Carlyle");
        test.setOnClickListener(v -> {
            status.setText("Invio test in corso...");
            NavSender.send(this, "right", "300 m", "Via Roma", "TEST", msg -> runOnUiThread(() -> status.setText(msg)));
        });
        l.addView(test);

        status = new TextView(this);
        status.setText("Stato: premi Diagnostica Carlyle");
        status.setTextSize(15);
        status.setPadding(0, 24, 0, 0);
        l.addView(status);

        setContentView(l);
        runDiagnostic();
    }

    void runDiagnostic() {
        status.setText("Cerco dispositivi Wear OS...");
        Wearable.getNodeClient(this).getConnectedNodes()
            .addOnSuccessListener(nodes -> {
                StringBuilder sb = new StringBuilder();
                sb.append("Nodi trovati: ").append(nodes.size()).append("\n");
                for (Node n : nodes) {
                    sb.append("• ").append(n.getDisplayName()).append("\n");
                }
                if (nodes.size() == 0) sb.append("Nessun Carlyle trovato. Apri Wear OS e verifica connessione.");
                status.setText(sb.toString());
            })
            .addOnFailureListener(e -> status.setText("Errore diagnostica: " + e.getMessage()));
    }
}
